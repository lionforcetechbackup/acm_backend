-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: accrepro.cbokga4lkail.ap-south-1.rds.amazonaws.com    Database: node_accrepro
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `organizations`
--

DROP TABLE IF EXISTS `organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `organizations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `company_type` int NOT NULL,
  `organization_type` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `country` int DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zipcode` varchar(255) DEFAULT NULL,
  `mobile_no` bigint DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `package` int DEFAULT NULL,
  `no_client_admin` int DEFAULT NULL,
  `no_viewer` int DEFAULT NULL,
  `no_surveyor` int DEFAULT NULL,
  `no_updator` int DEFAULT NULL,
  `package_start` datetime DEFAULT NULL,
  `valid_from` varchar(500) DEFAULT NULL,
  `valid_to` varchar(500) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `user_added` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organization_type` (`organization_type`),
  KEY `package` (`package`),
  CONSTRAINT `organizations_ibfk_1` FOREIGN KEY (`organization_type`) REFERENCES `organization_type` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `organizations_ibfk_2` FOREIGN KEY (`package`) REFERENCES `subscription_packages` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=454 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizations`
--

LOCK TABLES `organizations` WRITE;
/*!40000 ALTER TABLE `organizations` DISABLE KEYS */;
INSERT INTO `organizations` VALUES (67,'New',1,1,NULL,'superadmin@gmail.com',102,'Tamil Nadu','Chennai','#2 MG Road',NULL,9845652689,'super admin',1,3,5,13,4,NULL,'1620366606862----2021-05-07','1651989010321----2022-05-08',1,'2021-05-07 05:50:24','2021-09-16 06:18:21',NULL),(441,'Saggaf Eye Center',3,2,NULL,'volepal998@moenode.com',191,'WR','Jeddah','Abdullah Sulayman St. Al Fayha’a Jeddah 21418',NULL,126314004,'Dr. Zaki',2,1,4,5,5,NULL,'2022-05-06T22:50:32.967Z','2023-04-29T22:51:34.639Z',1,'2022-05-06 22:51:44','2022-09-09 04:04:35',NULL),(442,'Accrepro Development ',1,1,NULL,'xeyani7374@runqx.com',102,'andhara pradesh','chittor','ap',NULL,796322155,'Kameswar',1,10,30,14,20,NULL,'2022-06-16T05:47:47.465Z','2022-12-31T05:47:54.061Z',2,'2022-06-16 05:48:01','2022-06-24 12:50:16',NULL),(443,'Saggaf Eye Center()',3,2,NULL,'zakialmani@sagaf-eye.com',191,'WR','Jeddah','Abdullah Sulayman St. Al Fayha’a Jeddah 21418',NULL,126314004,'Dr. Zaki Almani',2,1,4,4,5,'2022-08-27 00:00:00','2022-08-27T01:39:18.357Z','2023-04-30T01:39:42.994Z',1,'2022-08-27 01:40:10','2022-08-27 01:40:10',NULL),(444,'Hospital',1,1,NULL,'lofawi7677@xitudy.com',191,'KSA','Dammam','Dammam, KSA',NULL,507183196,'Dr. Hatem',4,3,5,5,10,'2022-09-05 00:00:00','2022-09-05T11:04:28.824Z','2023-09-05T11:04:31.685Z',1,'2022-09-05 11:04:44','2022-09-05 11:04:44',NULL),(445,'Testing Accrepro',1,1,NULL,'letoga2582@bongcs.com',191,'AAAAA','BBBBBB','#!!!!!!',NULL,986532745,'Kameswar',1,10,30,14,20,'2022-09-20 00:00:00','2022-09-20T08:41:48.677Z','2022-12-31T08:41:51.799Z',1,'2022-09-20 08:44:13','2022-09-20 08:44:13',NULL),(446,'Branch 01',2,1,445,'letoga2582@bongcs.com',102,'Karnataka ','Bangalore ','HSR Layout',NULL,986532745,'Kameswar',1,10,30,14,20,'2022-09-20 00:00:00','2022-09-20','2022-12-31',1,'2022-09-22 11:13:31','2022-09-22 11:13:31',NULL),(448,'Healthcare Organization',1,1,NULL,'jisidam880@botsoko.com',191,'WR','Jeddah','Makkah Road',NULL,502415478,'Dr. Mohammed Abdullah',1,5,7,30,30,'2022-10-06 00:00:00','2022-10-06T02:25:48.485Z','2023-10-05T02:25:52.640Z',2,'2022-10-06 02:26:10','2022-10-06 05:52:09',NULL),(449,'Hospital Branch 1',2,1,448,'jisidam880@botsoko.com',191,'WR','Jeddah','Kandarah',NULL,502415478,'Dr. Mohammed Abdullah',4,3,5,5,10,'2022-10-06 00:00:00','2022-10-06','2023-10-05',2,'2022-10-06 02:28:21','2022-10-06 05:40:15',NULL),(450,'Hospital Branch 2',2,1,448,'jisidam880@botsoko.com',191,'WR','Jeddah','Mahjar',NULL,502415478,'Dr. Mohammed Abdullah',4,3,5,5,10,'2022-10-06 00:00:00','2022-10-06','2023-10-05',2,'2022-10-06 02:30:14','2022-10-06 05:40:27',NULL),(451,'Demo Hospital',1,1,NULL,'lahawav223@botsoko.com',191,'WR','Jeddah','Madinah Road',NULL,504123698,'Dr. Abdullah Qatani',1,10,30,14,20,'2022-10-06 00:00:00','2022-10-06T06:16:45.809Z','2023-10-05T06:16:48.862Z',1,'2022-10-06 06:16:59','2022-10-06 06:19:15',NULL),(452,'Branch 1 Hospital',2,1,451,'lahawav223@botsoko.com',191,'WR','Jeddah','Madinah Road',NULL,504123698,'Dr. Abdullah Qatani',1,10,30,14,20,'2022-10-06 00:00:00','2022-10-06','2023-10-05',1,'2022-10-06 06:24:44','2022-10-06 06:24:44',NULL),(453,'Branch 2 Hospital',2,1,451,'lahawav223@botsoko.com',191,'WR','Jeddah','Marwah',NULL,504123698,'Dr. Abdullah Qatani',1,10,30,14,20,'2022-10-06 00:00:00','2022-10-06','2023-10-05',1,'2022-10-06 06:27:18','2022-10-06 06:27:18',NULL);
/*!40000 ALTER TABLE `organizations` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-28 15:06:15
