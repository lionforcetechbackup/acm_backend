-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: accrepro.cbokga4lkail.ap-south-1.rds.amazonaws.com    Database: node_accrepro
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `download_samples`
--

DROP TABLE IF EXISTS `download_samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `download_samples` (
  `id` int NOT NULL AUTO_INCREMENT,
  `link` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `createdBy` int DEFAULT NULL,
  `updatedBy` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=388 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `download_samples`
--

LOCK TABLES `download_samples` WRITE;
/*!40000 ALTER TABLE `download_samples` DISABLE KEYS */;
INSERT INTO `download_samples` VALUES (376,'public/document/1651875007837-accrepro-SEC-CBAHI.csv','SEC-CBAHI',1,'2022-05-06 22:10:11','2022-05-06 22:10:11',1079,NULL),(377,'public/document/1651985902608-accrepro-SEC1-CBAHI.csv','SEC1-CBAHI',1,'2022-05-08 04:58:26','2022-05-08 04:58:26',1079,NULL),(378,'public/document/1657873728991-accrepro-SEC-CBAHI.csv','SEC-CBAHI',1,'2022-07-15 08:28:51','2022-07-15 08:28:51',25,NULL),(379,'public/document/1661563670758-accrepro-CSVAmbCBAHI.csv','CSVAmbCBAHI',1,'2022-08-27 01:27:53','2022-08-27 01:27:53',1079,NULL),(380,'public/document/1662113315732-accrepro-HospCBAHI.csv','HospCBAHI',1,'2022-09-02 10:09:06','2022-09-02 10:09:06',25,NULL),(381,'public/document/1662117119364-accrepro-HospCBAHI.csv','HospCBAHI',1,'2022-09-02 11:12:17','2022-09-02 11:12:17',25,NULL),(382,'public/document/1662118892044-accrepro-HospJCI.csv','HospJCI',1,'2022-09-02 11:41:46','2022-09-02 11:41:46',25,NULL),(383,'public/document/1663662461708-accrepro-TestAmbC.csv','TestAmbC',1,'2022-09-20 08:27:42','2022-09-20 08:27:42',25,NULL),(384,'public/document/1663662483698-accrepro-TestAmbJ.csv','TestAmbJ',1,'2022-09-20 08:28:04','2022-09-20 08:28:04',25,NULL),(385,'public/document/1665022210698-accrepro-CHStds.csv','CHStds',1,'2022-10-06 02:10:31','2022-10-06 02:10:31',25,NULL),(386,'public/document/1665022246696-accrepro-JHStds.csv','JHStds',1,'2022-10-06 02:10:54','2022-10-06 02:10:54',25,NULL),(387,'public/document/1665036823581-accrepro-00CStd.csv','00CStd',1,'2022-10-06 06:14:10','2022-10-06 06:14:10',25,NULL);
/*!40000 ALTER TABLE `download_samples` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-28 15:06:44
